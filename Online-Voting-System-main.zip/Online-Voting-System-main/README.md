# Online-Voting-System
The project consists of two parts one is admin and the other is the user. In order to cast your vote, you must log in to the system. The user can only cast his/her votes. As technology in the front end, we have used HTML, CSS. The Database used here is MYSQL Workbench.
